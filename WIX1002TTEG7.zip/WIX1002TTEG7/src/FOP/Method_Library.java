/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FOP;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.*;

/**
 *
 * @author Totroseah
 */
public class Method_Library {

    public static int ValidateNum() {
        int number = 0;
        boolean gate = false;
        String hold;
        Scanner keyboard = new Scanner(System.in);
        do {
            System.out.print("Please input the option number: ");
            hold = keyboard.nextLine();
            try {
                number = Integer.parseInt(hold);
                gate = false;
            } catch (Throwable e) {
                System.out.println("Please enter a valid choice");
                gate = true;
            }

        } while (gate);

        return number;
    }

    public static int InputNumRange(int max) {//Starts from 1 to max
        int choice;
        choice = ValidateNum();
        while ((choice <= 0) || (choice > max)) {
            System.out.println("");
            System.out.println("Please input the option number correctly!");
            choice = InputNumRange(max);
        }
        return choice;
    }

    public static int Moneymoneycomecome() {//Roll money to obtain        
        Random r = new Random();
        int ra = r.nextInt(5);
        int[] taxarray = new int[]{200, 250, 300, 350, 400};
        return taxarray[ra];
    }

    public static int[] TimeupHold(int time) {//know the time and season
        int[] timeLine = new int[2];

        int year, season;

        season = time % 4;
        {
            if (time % 4 == 0) {
                season += 4;
            }
        }
        year = time / 4 + 1;
        timeLine[0] = year;
        timeLine[1] = season;

        return timeLine;
    }

    public static boolean ChanceMou(double chance) {//Roll for a chance and return kena or not
        Random rand = new Random();

        int hold = rand.nextInt(100) + 1;
        chance *= 100;
        if (chance >= hold) {
            return true;
        } else {
            return false;
        }
    }

    public static void ClearScreen(int i) {//if pass 1 into, will wait for user press Enter key
        if (i == 1) {
            WaitEnter();
        }
        try {
            Robot pressbot = new Robot();
            pressbot.keyPress(17); // Holds CTRL key.
            pressbot.keyPress(76); // Holds L key.
            pressbot.keyRelease(76); // Releases L key.
            pressbot.keyRelease(17); // Releases CTRL key.
            pressbot.delay(100);
            //pressbot.keyPress(KeyEvent.VK_ENTER);
            //pressbot.keyRelease(KeyEvent.VK_ENTER);
        } catch (AWTException ex) {
            java.util.logging.Logger.getLogger(Method_Library.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

    }

    public static void WaitEnter() {//Wait for key press and continue
        Scanner s = new Scanner(System.in);
        System.out.println("Press Enter to continue...");
        s.nextLine();
    }

    public static void AskDiff() {
        System.out.println("");
        System.out.println("Please select the difficulty number.");
        System.out.println("1. EASY");
        System.out.println("2. NORMAL");
        System.out.println("3. HARD");
    }
}
