/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FOP;

/**
 *
 * @author Leong Tze Heng
 */
public class Countacc {
    static int recordacc;
    
    public Countacc(){
        this.recordacc = recordacc;
    }

    public int getRecordacc() {
        return recordacc;
    }

    public void setRecordacc(int recordacc) {
        this.recordacc = recordacc;
    }
    
    public String toString(){
        return "" + recordacc;
    }
}
